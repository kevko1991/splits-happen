"use strict";
exports.__esModule = true;
var process = require("process");
var bowling = /** @class */ (function () {
    function bowling(myArgs) {
        this.line = myArgs[0];
        this.frame = 1;
        this.turnCompleted = 0;
    }
    bowling.prototype.rollBallAndGetPoints = function (i) {
        var points;
        if (this.line[i] === 'X') { //strike
            points = 10 + this.getPointsHelper(i + 1) + this.getPointsHelper(i + 2);
            this.turnCompleted = 2;
        }
        else if (this.line[i] === '/') { //spare
            points = 10 - this.getPointsHelper(i - 1) + this.getPointsHelper(i + 1);
            this.turnCompleted = 2;
        }
        else if (this.line[i] === '-') { //miss
            points = 0;
            this.turnCompleted++;
        }
        else { //number of pins knocked down
            points = Number(this.line[i]);
            this.turnCompleted++;
        }
        return points;
    };
    bowling.prototype.getPointsHelper = function (i) {
        if (this.line[i] === 'X') { //strike
            return 10;
        }
        else if (this.line[i] === '/') { //spare
            return 10 - Number(this.line[i - 1]);
        }
        else if (this.line[i] === '-') { //miss
            return 0;
        }
        else { //number of pins knocked down
            return Number(this.line[i]);
        }
    };
    bowling.prototype.main = function () {
        var totalPoints = 0;
        var i = 0;
        while (this.frame <= 10) {
            totalPoints += this.rollBallAndGetPoints(i);
            //console.log( 'frame: '+this.frame + ' | turn completed:'+this.turnCompleted+ ' | total points:'+totalPoints);
            if (this.turnCompleted === 2) {
                this.turnCompleted = 0;
                this.frame++;
            }
            i++;
        }
        return totalPoints;
    };
    return bowling;
}());
exports.bowling = bowling;
//there was one argument pass through the command line. Look like a manual test is being ran. Shouldn't be effected regardless if it was not a manual test
if (process.argv.slice(2).length === 1) {
    var main = new bowling(process.argv.slice(2));
    console.log(main.main());
}
exports["default"] = bowling;
