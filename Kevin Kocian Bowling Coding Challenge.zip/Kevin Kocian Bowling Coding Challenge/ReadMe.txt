Kevin Kocian Submission


In command prompt
To run test:
	npm test
	
To compile typescript to javascript:
	tsc bowling.ts
	
To run javascript file:
	node bowling.js X7/9-X-88/-6XXX81