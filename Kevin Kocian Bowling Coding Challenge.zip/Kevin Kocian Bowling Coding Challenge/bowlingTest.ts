'use strict';

import bowling from './bowling';
import { expect } from 'chai';

describe('Bowling Test', function() {

    it('XXXXXXXXXXXX = 300', function () {
        let bowl = new bowling(['XXXXXXXXXXXX']);
        expect(bowl.main()).to.equal(300);
    });

    it('9-9-9-9-9-9-9-9-9-9- = 90', function () {
        let bowl = new bowling(['9-9-9-9-9-9-9-9-9-9-']);
        expect(bowl.main()).to.equal(90);
    });

    it('5/5/5/5/5/5/5/5/5/5/5 = 150', function () {
        let bowl = new bowling(['5/5/5/5/5/5/5/5/5/5/5']);
        expect(bowl.main()).to.equal(150);
    });

    it('X7/9-X-88/-6XXX81 = 167', function () {
        let bowl = new bowling(['X7/9-X-88/-6XXX81']);
        expect(bowl.main()).to.equal(167);
    });

});